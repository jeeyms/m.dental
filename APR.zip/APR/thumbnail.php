
				</ul>
							<div class="social_con">
								<div class="social_index">
								<div class="mm"><img src="img/32x32/facebook.png"></div><div class="fb"><a href="https://www.facebook.com/profile.php?id=100065627434891" target="_blank">Like us on Facebook</a></div>						
								</div>
							<div class="social_index">
							<div class="mm"><img src="img/32x32/gmail.png"></div><div class="fb"><a href="https://mail.google.com/mail/u/1/#inbox?compose=CllgCJqVxDcNSkZRsDbKQZssCZkJKgprlZmmxbKpdRbrkRNwGnNzQMsclhnpMmkGFdRRqWJJgLq" target="_blank">Message Us!</a></div>
							</div>
							</div>
							</div>
