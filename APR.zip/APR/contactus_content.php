
<div class="alert alert-info"><strong>Contact US</strong></div>
<div class="about">
<table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
    <tbody>
        <tr>
            <td>Cellphone Number</td>
            <td>09195388143 / 09063384641</td>
        </tr>

        <tr>
            <td>Facebook Page</td>
            <td>Machica Dental Clinic</td>
        </tr>

        <tr>
            <td>Gmail</td>
            <td>natzddm@gmail.com</td>
        </tr>

        
    </tbody>
</table>
</div>
