<div class="container">
  
  <div class="testimonial">
    <div class="caption_index_2">TESTIMONIAL</div>
    <div class="testimonial_div">
      <p>
        I was delighted with the treatment. Despite me being a somewhat difficult patient, Dr. Natividad Machica is patient and understanding. 
        The treatment was explained precisely to me, and the price was quoted right at the beginning, which is exactly what the price was at the end. 
        The transformation to my teeth and to my life in general has been amazing. 
        I now have a smile that I’m not afraid to show anymore. I am extremely happy with the quality of the treatment.
      </p>
    </div>
  </div>

  
  <div class="office_sitemap">
    <div class="contact_us">
      <div class="caption_index_2">VISIT OUR OFFICE</div>
      <p>Office Hours</p>
      <p>Monday - Saturday (9:00 am to 7:00 pm)</p>
      <p>Contact us: 09195388143 / 09063384641</p>
      <p>Dr. Natividad Machica</p>
      <p>Caloocan City, Metro Manila</p>
    </div>
    <div class="site_map">
      <iframe 
        width="300" 
        height="300" 
        frameborder="0" 
        scrolling="no" 
        marginheight="0" 
        marginwidth="0" 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d480.6156335824869!2d120.98880262367899!3d14.65575939155907!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b681f377ce0f%3A0xb18a290a0f5fd477!2sMachica%20Dental%20Clinic!5e1!3m2!1sen!2sph!4v1731927124532!5m2!1sen!2sph" 
        style="border:0;" 
        allowfullscreen="" 
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>
  </div>
</div>

<style>

.container {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}

.testimonial {
  flex: 1 1 100%;
}

.office_sitemap {
  flex: 1 1 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.contact_us, .site_map {
  flex: 1 1 auto;
}


@media (min-width: 768px) {
  .container {
    flex-wrap: nowrap;
  }
  .testimonial {
    flex: 2;
  }
  .office_sitemap {
    flex: 1;
    flex-direction: row;
    justify-content: space-between;
  }
  .contact_us, .site_map {
    flex: 1 1 50%;
  }
}
</style>
