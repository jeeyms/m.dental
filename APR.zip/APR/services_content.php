<div class="alert alert-info">List of Serivices Offered	</div>
       <table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
                            
                                <thead>
                                    <tr>
                                        <th>Service Offer</th>
                                        <th>Price</th>                       
                                    </tr>
                                </thead>
                                <tbody>
								 
                                  <tr class>
                                    <td>Oral Prophylaxis/Cleaning</td>
                                    <td>750.00</td>
                                  </tr>

                                  <tr class>
                                    <td>Tooth Restoration/Pasta</td>
                                    <td>750.00</td>
                                  </tr>

                                  <tr class>
                                    <td>Tooth Extraction</td>
                                    <td></td>
                                  </tr>

                                  <tr class>
                                    <td>Anterior tooth/harap na ipin</td>
                                    <td>750.00</td>
                                  </tr>

                                  <tr class>
                                    <td>Posterior/bagang</td>
                                    <td>850.00</td>
                                  </tr>

                                  <tr class>
                                    <td>Odontectomy/Wisdom tooth removal</td>
                                    <td>8000-10000</td>
                                  </tr>

                                  <tr class>
                                    <td>Frenectomy</td>
                                    <td>8000</td>
                                  </tr>

                                  <tr class>
                                    <td>Gumtectomy</td>
                                    <td>8000</td>
                                  </tr>

                                  <tr class>
                                    <td>Root Canal Treatment (per canal)</td>
                                    <td>4000</td>
                                  </tr>

                                  <p>
                                    For other inquiries, please login or make an account in our page. 
                                  </p>
                           
                                </tbody>
                            </table>